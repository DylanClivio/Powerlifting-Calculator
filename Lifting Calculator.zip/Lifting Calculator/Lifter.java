// This is the class "lifter". It will collect information on a powerlifting athlete and calculate their strength
public class Lifter {

    // First we declare the 3 variables we will be collecting to establish a profile of the powerlifter, and using in our math
    private String athlete;
    private String lift;
    private int weight;

    // Next we create a Lifter method that collects the 3 variables we declared as parameters
    public Lifter(String athlete, String lift, int weight){

        this.athlete = athlete;
        this.lift = lift;
        this.weight = weight;
        
        // Next we use if statements to understand the users inputs and print out what their strength is estimated to be in the other lifts they did not enter
        if (lift.equals("bench press")){
            int squat = (weight / 3) * 4;
            int deadlift = (weight / 3) * 5;
            System.out.println("\nBased off of " + athlete + "s" + " " + lift + ", and the 3:4:5 ratio, " + athlete + " should be able to squat about " + squat + "lbs, and deadlift " + deadlift + "lbs.");

            // Next we create an array that will have elements composed of the powerlifters estimated strengths and the users input lift
            int[] ORM = {squat, deadlift, weight};

            // Next we declare variabes we will use to determine how many times to run our for loop
            // we use the ".length" method to make the variable x equal the number of elements in our array
            int x = ORM.length;
            int sum = 0;

            // The for loop will add all of the elements in our array to a sum
            for(int i = 0; i < x; i++){
                sum += ORM[i];
            }

            // Lastly, we print out the powerlifters theoretical total
            System.out.println("That makes " + athlete + "s theoretical total for all three lifts = " + sum + "lbs!\n");

            // The following if statements repeat the syntax from above and do the same thing as above except based off of the different possible user inputs for their lift
        } if (lift.equals("deadlift")){
            int squat = (weight / 5) * 4;
            int bench = (weight / 5) * 3;
            System.out.println("\nBased off of " + athlete + "s" + " " + lift + ", and the 3:4:5 ratio, " + athlete + " should be able to squat about " + squat + "lbs, and bench " + bench + "lbs.");

            int[] ORM = {squat, bench, weight};

            int x = ORM.length;

            int sum = 0;

            for(int i = 0; i < x; i++){
                sum += ORM[i];
            }

            System.out.println("That makes " + athlete + "s theoretical total for all three lifts = " + sum + "lbs!\n");

        } if (lift.equals("squat")){
            int deadlift = (weight / 4) * 5;
            int bench = (weight / 4) * 3;
            System.out.println("\nBased off of " + athlete + "s" + " " + lift + ", and the 3:4:5 ratio,  " + athlete + " should be able to deadlift about " + deadlift + "lbs, and bench " + bench +"lbs.");

            int[] ORM = {deadlift, bench, weight};

            int x = ORM.length;

            int sum = 0;

            for(int i = 0; i < x; i++){
                sum += ORM[i];
            }

            System.out.println("That makes " + athlete + "s theoretical total for all three lifts = " + sum + "lbs!\n");
        }
}
}