// The following imports a Scanner so we can collect inputs from the user
import java.util.Scanner;

// the following is the main class of the program
public class Main {
    public static void main(String[] args) throws Exception {

        // First we collect the users name, or in this case, the name of a powerlifter
        System.out.print("Please enter the name of the powerlifter: ");

        // Then, we can reference the Scanner we imported so we can collect input from the user
        Scanner prompt = new Scanner(System.in);

        // We save this input as a string
        String name = prompt.nextLine();

        // Then we ask the user what lift of theirs they want to use to calculate their estimated strength in other lifts
        System.out.println("\nLifts: (Bench press = 1) (Squat = 2) (Deadlift = 3)");
        System.out.print("Please enter a number that coincides with one of the three lifts: ");
        Scanner prompt2 = new Scanner(System.in);

        // we save this input as an integer
        int lift = prompt2.nextInt();

        // The following declares a String variable that we will determine the value of with an if statement
        String liftconverted = "";

        // this process is so that the program can convert the users input (an integer) into a string that is referring to the lift they chose by number
        if (lift == 1){
            liftconverted = "bench press";
        }
        if (lift == 2){
            liftconverted = "squat";
        }
        if (lift == 3){
            liftconverted = "deadlift";
        }

        // Then we ask the user for the amount of weight the athlete can lift in whatever lift they specified in the previous input
        System.out.print("\nPlease enter an integer that is equal to the amount of weight that " + name + " can lift in lbs in the " + liftconverted + ": ");
        Scanner finalinput = new Scanner(System.in);

        // We save the input as an integer
        int weight = finalinput.nextInt();
        
        // Lastly, we use the 3 user inputs we have collected to fill the perameters of the method we created within the class "Lifter"
        // The class "Lifter" will handle all the necassary math involved with the program and then print out the final result
        Lifter FinalOutput = new Lifter(name, liftconverted, weight);
    }
}